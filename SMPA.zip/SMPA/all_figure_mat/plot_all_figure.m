load('figure2.mat');


imagesc(P);
colormap(cool);
colorbar;
title('P');

%%%%%%%%%%%%%%%%%%%%%%
load('figure3.mat');
result2=(SMPA-SGITMA)./SGITMA*100;
plot(M,result2,'-b*');
xlabel('M');ylabel('PIP');
ylim([0,110]);
hold on;
grid on;


plot(M,SGITMA,'-ro');
hold on;
plot(M,SMPA,'-b*');
hold on;
grid on;
plot(M,SVD1,'-*');
xlabel('M');ylabel('CE(Nat)');
legend('SGITMA','SMPA','SVD');


plot(M,SGITMA_iter,'-ro');
hold on;
grid on;
plot(M,SMPA_iter,'-b*');
xlabel('M');ylabel('Iteration Number');
legend('SGITMA','SMPA');


%%%%%%%%%%%%
load('figure4.mat');
mean_SMPA=-mean(M_iter_PSIB_GSD1,1);
mean_SGITMA=-mean(M_iter_SIB,1);

var_SMPA=std(M_iter_PSIB_GSD1);
var_SGITMA=std(M_iter_SIB);

errorbar(categories, mean_SGITMA-EI_old, var_SGITMA, 'ro', 'MarkerSize', 3, 'LineWidth', 2.5);
hold on;

errorbar(categories,mean_SMPA-EI_old, var_SMPA, 'b*', 'MarkerSize', 6, 'LineWidth', 1.5);
xlabel('M');
ylabel('CE(Nat)');
grid on;
hold off;
legend('SGITMA','SMPA');




mean_time_SGITMA=mean(time_SIB_all,1);
mean_time_SMPA=mean(time_PSIB_all,1);

var_time_SGITMA=std(time_SIB_all);
var_time_SMPA=std(time_PSIB_all);


errorbar(categories, mean_time_SGITMA, var_time_SGITMA, 'ro', 'MarkerSize', 1, 'LineWidth', 2.5);
hold on;

errorbar(categories,mean_time_SMPA, var_time_SMPA, 'b*', 'MarkerSize', 6, 'LineWidth', 1.5);
xlabel('M');
ylabel('runtime(s)');

grid on;
hold off;
legend('SGITMA','SMPA');



%%%%%%%%%%delta
load('Figure5a.mat');
x_labels = delta;
x_ticks = 1:length(x_labels);
plot(x_ticks,SMPA_all(:,1)','-r*');
hold on;
plot(x_ticks,SMPA_all(:,2)','-b*');
hold on;
plot(x_ticks,SMPA_all(:,3)','-*');
grid on;
set(gca, 'XTick', x_ticks, 'XTickLabel', num2str(x_labels'));

xlabel('\delta');ylabel('CE(Nat)');
legend('M=10','M=20','M=25');

%%%%%%%%%%%%I
load('Figure5b.mat');

plot(I,SMPA_all(:,1)','-r*');
hold on;
plot(I,SMPA_all(:,2)','-b*');
hold on;
plot(I,SMPA_all(:,3)','-*');
grid on;


xlabel('I');ylabel('CE(Nat)');
legend('M=10','M=20','M=25');

%%%%%%%%%%%%S
load('Figure5c.mat');


plot(S,SMPA_all(:,1)','-r*');
hold on;
plot(S,SMPA_all(:,2)','-b*');
hold on;
plot(S,SMPA_all(:,3)','-*');
grid on;


xlabel('S');ylabel('CE(Nat)');
legend('M=10','M=20','M=25');

%%%%%%%%%%%%R
load('Figure5d.mat');

plot(R,SMPA_all(:,1)','-r*');
hold on;
plot(R,SMPA_all(:,2)','-b*');
hold on;
plot(R,SMPA_all(:,3)','-*');
grid on;


xlabel('R');ylabel('CE(Nat)');
legend('M=10','M=20','M=25');

xlabel('R');ylabel('CE(Nat)');
legend('M=10','M=20','M=25');


%%%%%%%%%%%%%%%%%%%%
load('figure6.mat');

plot(M,SGITMA,'-ro');
hold on;
plot(M,SMPA,'-b*');
hold on;
grid on;
plot(M,SVD1,'-*');
xlabel('M');ylabel('CE(Nat)');
legend('SGITMA','SMPA','SVD');

result2=(SMPA-SGITMA)./SGITMA*100;
plot(M,result2,'-b*');
xlabel('M');ylabel('PIP');
ylim([0,30]);
hold on;
grid on;





plot(M,SGITMA_iter,'-ro');
hold on;
grid on;
plot(M,SMPA_iter,'-b*');
xlabel('M');ylabel('Iteration Number');
legend('SGITMA','SMPA');



%%%%%%%%%%%%%%%%%%%%
load('figure7.mat');
imagesc(P);
colormap(cool);
colorbar;
title('P');

%%%%%%%%%%%%%%%%%%%%
load('figure8.mat');

result2=(SMPA-SGITMA)./SGITMA*100;
plot(M,result2,'-b*');
xlabel('M');ylabel('PIP');
ylim([0,16]);
hold on;
grid on;


plot(M,SGITMA,'-ro');
hold on;
plot(M,SMPA,'-b*');
hold on;
grid on;

plot(M,SVD1,'-*');
xlabel('M');ylabel('CE(Nat)');
legend('SGITMA','SMPA','SVD');

plot(M,SGITMA_iter,'-ro');
hold on;
grid on;
plot(M,SMPA_iter,'-b*');
xlabel('M');ylabel('Iteration Number');
legend('SGITMA','SMPA');


%%%%%%%%%%%%%%%%%%%%
load('figure9.mat');
result2=(SMPA-SGITMA)./SGITMA*100;
plot(M,result2,'-b*');
xlabel('M');ylabel('PIP');
ylim([0,20]);
hold on;
grid on;


plot(M,SGITMA,'-ro');
hold on;
plot(M,SMPA,'-b*');
hold on;
grid on;

plot(M,SVD1,'-*');
xlabel('M');ylabel('CE(Nat)');
legend('SGITMA','SMPA','SVD');


plot(M,SGITMA_iter,'-ro');
hold on;
grid on;
plot(M,SMPA_iter,'-b*');
xlabel('M');ylabel('Iteration Number');
legend('SGITMA','SMPA');





