function [W,obj_value_iter] = fun_PSIB_GSD(iter_number,N,M,P,Q,W,u,GSD_iter,GSD_range,Delta,delta)
obj_value_iter=zeros(iter_number,1);
for iter=1:iter_number
    for i=1:N
        temp_value=ones(M,1);
        obj_value=1000*ones(M,1);
        for jj=1:M
            obj_value_temp=ones(GSD_iter+1,1);
            Gama=[0.25,0.5,0.75,W(i,jj)];
            [temp,obj_value_temp(GSD_iter+1)]=fun_init(i,jj,Q,W,u,Gama);            
            alpha_jj=ones(GSD_iter,1)*temp;beta_jj=ones(GSD_iter,1)*temp;
            flag=0;
            if(W(i,jj)==0)
                alpha1=temp;
                for kk=1:GSD_iter
                    grad = fun_compute_gradient(M,P,W,u,i,jj,alpha1,alpha1);
                    alpha1=alpha1+GSD_range*sign(grad)*Delta^kk;
                    if (alpha1<=0) || (alpha1>=1)
                        Gama2=[0.1:0.8/(GSD_iter-kk+1):0.9];
                        [alpha1,~]=fun_init(i,jj,Q,W,u,Gama2);
                        flag=1;

                    end
                    k1_old=find(W(i,:)>0);
                    W2=W;

                    W2(i,k1_old)=(1-alpha1)*W2(i,k1_old);W2(i,jj)=alpha1;
                    alpha_jj(kk)=alpha1;
                    temp1=sum(W2,1);
                    if sum(temp1>0)<M
                        obj_value_temp(kk)=1000;
                    else
                        obj_value_temp(kk)=fun_compute_obj_value(Q,W2,u);
                    end
                    if flag==1
                        break;
                    end
                end





            elseif W(i,jj)<1
                beta1=temp;
                for kk=1:GSD_iter
                    grad = fun_compute_gradient(M,P,W,u,i,jj,beta1,beta1);
                    beta1=beta1+GSD_range*sign(grad)*Delta^kk;
                    if (beta1<=0)||(beta1>=1)
                        Gama2=[0.1:0.8/(GSD_iter-kk+1):0.9];
                        [beta1,~]=fun_init(i,jj,Q,W,u,Gama2);
                        flag=1;

                    end
                    k2_old=find(W(i,:)>0);
                    W2=W;
                    W2(i,k2_old)=(1-beta1)*W(i,k2_old)/(1-W(i,jj));
                    W2(i,jj)=beta1;
                    beta_jj(kk)=beta1;
                    temp1=sum(W2,1);
                    if sum(temp1>0)<M
                        obj_value_temp(kk)=1000;
                    else
                        obj_value_temp(kk)=fun_compute_obj_value(Q,W2,u);
                    end
                    if flag==1
                        break;
                    end
                end



            end
            [obj_value(jj),kkk]=min(obj_value_temp);
            if kkk<GSD_iter+1
                if W(i,jj)==0
                    temp_value(jj)=alpha_jj(kkk);
                elseif  W(i,jj)<1
                    temp_value(jj)=beta_jj(kkk);
                end
            else
                temp_value(jj)=W(i,jj);
            end


        end
        [~,kkkk]=min(obj_value);
        if W(i,kkkk)==0
            k1_old=find(W(i,:)>0);
            alpha1= temp_value(kkkk);
            W(i,k1_old)=(1-alpha1)*W(i,k1_old);W(i,kkkk)=alpha1;
        elseif W(i,kkkk)<1
            k2_old=find(W(i,:)>0);
            beta1= temp_value(kkkk);
            W(i,k2_old)=(1-beta1)*W(i,k2_old)/(1-W(i,kkkk));
            W(i,kkkk)=beta1;
        end


    end
    obj_value_iter(iter)=fun_compute_obj_value(Q,W,u);

    if( iter>1 && abs(obj_value_iter(iter)-obj_value_iter(iter-1))<=delta)

        break;
    end



end
obj_value_iter(iter+1:iter_number)=obj_value_iter(iter)*ones(iter_number-iter,1);
end



