function outputArg1 = fun_compute_obj_value(Q,W,u)

M=size(W,2);
Q1=W'*Q*W; 

u1=sum(Q1,1);
kkk=find(u1==0);
uu1=diag(1./u1);
for jj=1:size(kkk,2)
    uu1(kkk(jj),kkk(jj))=0;
end
P1_transfer=uu1*Q1;
P1_transfer_average=mean(P1_transfer,1);
P1_transfer_average(P1_transfer_average<=10^(-10))=10^(-10);
P1_transfer(P1_transfer<=10^(-10))=10^(-10);
outputArg1 =-1/M*(sum(sum(P1_transfer.*log(P1_transfer))))+sum(P1_transfer_average.*log(P1_transfer_average));


end

