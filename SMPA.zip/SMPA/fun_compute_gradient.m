function grad = fun_compute_gradient(M,P,W,u,i,jj,alpha,beta)
grad_Q=zeros(M,M);
if W(i,jj)==0 
    PW1=P*W;
    WtmuP=W'*diag(u)*P;
    for mm=1:M
        for nn=1:M
            theory_gra1=-u(i)*W(i,mm)*PW1(i,nn)-W(i,nn)*WtmuP(mm,i);
            theory_gra2=0;
            theory_gra3=0;
            theory_gra4=0;

            if nn==jj
                theory_gra2=-W(i,mm)*u(i)*P(i,i)*(alpha-(1-alpha)*W(i,jj))+WtmuP(mm,i)*(1+W(i,jj));
            end
            if mm==jj
                theory_gra3=-(alpha-(1-alpha)*W(i,mm))*u(i)*P(i,i)*W(i,nn)+PW1(i,nn)*u(i)*(1+W(i,mm));
            end

            if mm==jj && nn==jj
                theory_gra4=2*(1+W(i,mm))*u(i)*P(i,i)*(alpha-(1-alpha)*W(i,mm));
            end

            grad_Q(mm,nn)=theory_gra1+theory_gra2+theory_gra3+theory_gra4;
        end
    end
    phi=-u(i)*W(i,:);
    phi(jj)=u(i);
    W1=W;
    W1(i,:)=(1-alpha)*W(i,:);
    W1(i,jj)=alpha;
    mu2=u*W1;
    delta_P=diag(mu2.^(-2))*(diag(mu2)*grad_Q-diag(phi)*W1'*diag(u)*P*W1);


    P_new=diag(1./(u*W1))*W1'*diag(u)*P*W1;
    P_mean_sum1=mean(P_new,1);

    P_new(P_new<=10^(-10))=10^(-10);
    P_mean_sum1(P_mean_sum1<=10^(-10))=10^(-10);

    grad=1/M*sum(sum(delta_P.*(1+log(P_new))))-sum(mean(delta_P,1).*(1+log(P_mean_sum1)));
else                


    PW1=P*W;
    WtmuP=W'*diag(u)*P;
    for mm=1:M
        for nn=1:M
            theory_gra1=-u(i)*W(i,mm)/(1-W(i,jj))*PW1(i,nn)-W(i,nn)/(1-W(i,jj))*WtmuP(mm,i);
            theory_gra2=0;
            theory_gra3=0;
            theory_gra4=0;
            if nn==jj
                theory_gra2=-W(i,mm)/(1-W(i,jj))*u(i)*P(i,i)*(beta-(1-beta)*W(i,jj)/(1-W(i,jj)))+WtmuP(mm,i)*(1+W(i,jj)/(1-W(i,jj)));
            end
            if mm==jj
                theory_gra3=-(beta-(1-beta)*W(i,jj)/(1-W(i,jj)))*u(i)*P(i,i)*W(i,nn)+PW1(i,nn)*u(i)*(1+W(i,mm)/(1-W(i,jj)));
            end
            if mm==jj && nn==jj
                theory_gra4=2*u(i)*P(i,i)*(beta-(1-beta)*W(i,jj)/(1-W(i,jj)))*(1+W(i,jj)/(1-W(i,jj)));
            end


            grad_Q(mm,nn)=theory_gra1+theory_gra2+theory_gra3+theory_gra4;
        end
    end

    phi=-u(i)*W(i,:)/(1-W(i,jj));
    phi(jj)=u(i);
    W1=W;
    W1(i,:)=(1-beta)*W(i,:)/(1-W(i,jj));
    W1(i,jj)=beta;


    mu2=u*W1;
    delta_P=diag(mu2.^(-2))*(diag(mu2)*grad_Q-diag(phi)*W1'*diag(u)*P*W1);


    P_new=diag(1./(u*W1))*W1'*diag(u)*P*W1;
    P_mean_sum1=mean(P_new,1);

    P_new(P_new<=10^(-10))=10^(-10);
    P_mean_sum1(P_mean_sum1<=10^(-10))=10^(-10);

    grad=1/M*sum(sum(delta_P.*(1+log(P_new))))-sum(mean(delta_P,1).*(1+log(P_mean_sum1)));
end





