function [output1,output2] = fun_init(i,jj,Q,W,u,Gama)
if W(i,jj)==1
    output1=1;
    output2=fun_compute_obj_value(Q,W,u);
else
    size2=size(Gama,2);
    k1_old=find(W(i,:)>0);
    obj_value=zeros(size2,1);
    obj_value(size2)=fun_compute_obj_value(Q,W,u);
    for ii=1:size2-1
        W1=W;
        if W1(i,jj)==0
            alpha1=Gama(ii);
            W1(i,k1_old)=(1-alpha1)*W1(i,k1_old);W1(i,jj)=alpha1;
            obj_value(ii)=fun_compute_obj_value(Q,W1,u);
        elseif W1(i,jj)<1
            beta1=Gama(ii);
            W1(i,k1_old)=(1-beta1)*W1(i,k1_old)/(1-W1(i,jj));
            W1(i,jj)=beta1;
            obj_value(ii)=fun_compute_obj_value(Q,W1,u);
        end
    end
    [output2,kkk]=min(obj_value);
    output1=Gama(kkk);
   
end
