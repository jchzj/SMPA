function bin2=fun_num_2_bin(number,dim1)
bin1=dec2bin(number-1);
c1=str2num(bin1(1));
for i=2:length(bin1)
    c1=[c1 str2num(bin1(i))];
end
bin2=[zeros(1,dim1-length(bin1)) c1]';

