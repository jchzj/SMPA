clear all;
close all;

iter_number=50;
number_A=6;
connection_matrix=zeros(number_A,number_A);

prob_matrix=[0.7 0.3; 0.7 0.3; 0.7 0.3;0.1 0.9];
state_matrix=zeros(4,4);
for i=1:4
    for j=1:4
        bin1=fun_num_2_bin(j,2);
        state_matrix(i,j)=prob_matrix(i,bin1(1)+1)*prob_matrix(i,bin1(2)+1);
    end
end


% for i=1:6
%     if(i<=number_A-2)
%         if mod(i,2)==1
%             connection_matrix(i,i+2)=1;
%             connection_matrix(i,i+3)=1;
%         else
%             connection_matrix(i,i+2)=1;
%             connection_matrix(i,i+1)=1;
%         end
%     else
%          if mod(i,2)==1
%             connection_matrix(i,1)=1;
%             connection_matrix(i,2)=1;
%         else
%             connection_matrix(i,2)=1;
%             connection_matrix(i,1)=1;
%          end
%     end
% end

P=zeros(2^number_A,2^number_A);

for ii=1:2^number_A
    bin2=fun_num_2_bin(ii,number_A);

    for jj=1:2^number_A
        bin3=fun_num_2_bin(jj,number_A);
        temp_prob=zeros(3,1);
        for jjj=1:3
            temp_jj=bin2dec(num2str(bin3(2*jjj-1:2*jjj)'))+1;
            if jjj==1
                temp_ii=bin2dec(num2str(bin2(number_A-1:number_A)'))+1;
            else
                temp_ii=bin2dec(num2str(bin2(2*jjj-3:2*jjj-2)'))+1;
            end
            temp_prob(jjj)=state_matrix(temp_ii,temp_jj);
        end
        P(ii,jj)=prod(temp_prob);
    end
end



N=2^number_A;
x_init=rand(1,N);
x_init=x_init/sum(x_init);
F = @(x) [(x*P-x)';
    sum(x)-1];
u = fsolve(F,x_init);

M_number=4;
repeat_number=50;
delta=1e-3;


M_iter_PSIB_GSD1=zeros(iter_number,M_number);
M_init=5;
for jjj=1:M_number
    M=5*jjj+M_init;
    obj_value_iter_PSIB_GSD_repeat1=zeros(iter_number,repeat_number);
    for kk=1:repeat_number
        W=zeros(N,M);
        mm=randperm(M);
        nn=randperm(N);
        for i=1:M
            W(nn(i),mm(i))=1;
        end
        for i=M+1:N
            W(nn(i),randi([1,M]))=1;
        end
        W_PSIB_init=W;
        for i=1:N
            k1=find(W(i,:)>0);
            k2=randi([1,M]);
            while k1==k2
                k2=randi([1,M]);
            end
            
            W_PSIB_init(i,k1)=rand();
            W_PSIB_init(i,k2)=1-W_PSIB_init(i,k1);
        end
        W=W_PSIB_init;

        Q=diag(u)*P;




        [W_PSIB_GSD1,obj_value_iter_PSIB_GSD_repeat1(:,kk)]= fun_PSIB_GSD(iter_number,N,M,P,Q,W,u,10,0.25,0.9,delta);

    end
  
    [~,kkk_PSIB_GSD1]=min(obj_value_iter_PSIB_GSD_repeat1(iter_number,:));
    M_iter_PSIB_GSD1(:,jjj)=obj_value_iter_PSIB_GSD_repeat1(:,kkk_PSIB_GSD1);
end

